from cv2 import *
import numpy as np


###
black = [0,0,0]
brown = [4,24,67]
red = [0,0,255]
green = [0,255,0]
blue = [255,0,0]
orange = [37,90,249]
yellow = [51,239,245]
violet = [240,80,170]
gray = [126,126,126]
silver = [200,200,200]
gold = [6,122,222]

def changeColor(img,colors):
    #img = imread(path)
    a,b,c,d = colors
    ### pre defined colors
    rd = [0,0,255]
    pink = [255,0,255]
    bl = [255,0,0]
    gr = [0,128,0]

    h,w = img.shape[0:2]

    for i in range(h):
        for j in range(w):
            color = img[i,j].tolist()

            if color==rd:
                img[i,j] = a
            if color==pink:
                img[i,j] = b
            if color==bl:
                img[i,j] = c
            if color==gr:
                img[i,j] = d
    return img

if __name__ == "__main__":
    o = changeColor("images/resistor.bmp",[black,blue,green,yellow])

'''img = imread("images/resistor.bmp")

h,w = img.shape[0:2]

fg = [128, 128, 128]

### strip colors
rd = [0,0,255]
pink = [255,0,255]
bl = [255,0,0]
gr = [0,128,0]

###
black = [0,0,0]
brown = [4,24,67]
red = [0,0,255]
green = [0,255,0]
blue = [255,0,0]
orange = [37,90,249]
yellow = [51,239,245]
violet = [240,80,170]
gray = [126,126,126]
silver = [200,200,200]
gold = [6,122,222]

def changeColor(img,colors):
    a,b,c,d = colors
    ### pre defined colors
    rd = [0,0,255]
    pink = [255,0,255]
    bl = [255,0,0]
    gr = [0,128,0]
    for i in range(h):
        for j in range(w):
            color = img[i,j].tolist()

            if color==rd:
                img[i,j] = a
            if color==pink:
                img[i,j] = b
            if color==bl:
                img[i,j] = c
            if color==gr:
                img[i,j] = d
    return img
            
img = changeColor(img,[red,red,yellow,gold])
imshow("resistor", img)
waitKey(0)
destroyAllWindows()'''
