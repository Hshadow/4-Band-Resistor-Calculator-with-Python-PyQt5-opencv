import subprocess

pyqt5 = ["pip", "install", "PyQt5"]
cv2 = ["pip", "install", "opencv-python"]

### install PyQt5 gui package
print("{}".format(" ".join(pyqt5)), end="\n")
out = subprocess.check_output(pyqt5, shell = True)
print(out.decode(), end = "\n\n")

### install pyautogui gui automation module
print("{}".format(" ".join(cv2)), end="\n")
out = subprocess.check_output(cv2, shell = True)
print(out.decode(), end = "\n\n")
