
### digit digit multiplier tolerance                -  4 Band
### digit digit digit multiplier tolerance          -  5 Band
### digit digit digit multiplier tolerance tcr      -  6 Band

### tcr = Temperature Co-efficient of Resistence

color_data = {
            'black':
            {"digit":0,"multiplier":10**0,"tolerance":None,"tcr":None},
            'brown':
            {"digit":1,"multiplier":10**1,"tolerance":[1, "F"],"tcr":100},
            'red':
            {"digit":2,"multiplier":10**2,"tolerance":[2, "G"],"tcr":50},
            'orange':
            {"digit":3,"multiplier":10**3,"tolerance":None,"tcr":15},
            'yellow':
            {"digit":4,"multiplier":10**4,"tolerance":None,"tcr":25},
            'green':
            {"digit":5,"multiplier":10**5,"tolerance":[0.5, "D"],"tcr":None},
            'blue':
            {"digit":6,"multiplier":10**6,"tolerance":[0.25, "C"],"tcr":10},
            'violet':
            {"digit":7,"multiplier":10**7,"tolerance":[1.10, "B"],"tcr":5},
            'gray':
            {"digit":8,"multiplier":10**8,"tolerance":[0.05, None],"tcr":None},
            'white':
            {"digit":9,"multiplier":10**9,"tolerance":None,"tcr":None},
            'gold':
            {"digit":None,"multiplier":10**-1,"tolerance":[5, "J"],"tcr":None},
            'silver':
            {"digit":None,"multiplier":10**-2,"tolerance":[10, "K"],"tcr":None}
        }

if __name__ == "__main__":
    print(color_data)
