from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from cv2 import *
from ui import main
import resistor_data as rs
import img_control as ctrl

class Band_4(main.Ui_MainWindow, QMainWindow):
    def __init__(self):
        super(Band_4, self).__init__()
        self.setupUi(self)
        self.digits = [0,0]
        self.other = [0,0]
        self.colors = [""]*4
        self.d2.setEnabled(False)
        self.mul.setEnabled(False)
        self.tol.setEnabled(False)
        self.d1.currentIndexChanged.connect(self.digitChange)
        self.d2.currentIndexChanged.connect(self.digitChange)
        self.mul.currentIndexChanged.connect(self.final)
        self.tol.currentIndexChanged.connect(self.final)
        self.ok.clicked.connect(self.calculate)
        self.ok.setStyleSheet("color: lime; background-color: black; border-color: black; border-style: dotted; border-width: 2; border-radius: 50;")
        self.data = rs.color_data
        icon = QIcon()
        icon.addPixmap(QPixmap("images/no color.png"), QIcon.Normal, QIcon.Off)
        self.tol.addItem(icon, "no color")
    def digitChange(self):
        obj = self.sender().objectName()
        if obj == "d1":
            self.d2.setEnabled(True)
        if obj == "d2":
            self.mul.setEnabled(True)
        c1 = self.d1.currentText()
        c2 = self.d2.currentText()
        d1 = self.data[c1]['digit']
        d2 = self.data[c2]['digit']
        self.digits = [d1,d2]
        self.colors[0:2] = [c1, c2]

    def final(self):
        self.tol.setEnabled(True)
        obj = self.sender().objectName()
        m = self.mul.currentText()
        t = self.tol.currentText()
        mul = self.data[m]['multiplier']
        if t == "no color":
            tol = 20
        else:
            tol = self.data[t]['tolerance'][0]
        self.other = [mul,tol]
        self.colors[2:4] = [m, t]

    def image_control(self):
        ### colors
        black = [0,0,0]
        brown = [4,24,67]
        red = [5,5,206]
        green = [17,176,12]
        blue = [157,65,15]
        orange = [37,90,249]
        yellow = [51,239,245]
        violet = [240,80,170]
        gray = [126,126,126]
        white = [255,255,255]
        silver = [200,200,200]
        gold = [6,122,222]
        nc = [160,214,255]

        data = {"black":black,"brown":brown,"red":red, "green":green, "blue":blue, "orange":orange, "yellow":yellow, "violet":violet, "gray":gray, "white":white, "silver":silver, "gold":gold, "no color":nc}
        colors = []
        for c in self.colors:
            colors.append(data[c])
        
        path = "images/resistor2.png"
        img = imread(path)
        img = ctrl.changeColor(img,colors)
        qimg = QImage(img, img.shape[1], img.shape[0], QImage.Format_RGB888).rgbSwapped()
        self.resistor.setPixmap(QPixmap.fromImage(qimg))

    def calculate(self):
        d1,d2 = self.digits
        mul,tol = self.other
        
        num = int("%s%s"%(d1,d2))
        if num*mul>=1000:
            cal = "%sk"%int(num*mul/1000)
        else:
            cal = "%s"%(num*mul)
        c = " "*4+"%s Ω, %.2f"%(cal, tol)+"%"
        self.display.setText(c)
        self.image_control()
        


if __name__ == "__main__":
    app = QApplication([])
    obj = Band_4()
    obj.show()
    app.exec_()
